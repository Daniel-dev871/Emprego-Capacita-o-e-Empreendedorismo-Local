import React, { useState, useEffect } from 'react';
import api from './services/api';
import { Briefcase, BookOpen, Users, MapPin, Building } from 'lucide-react';

export default function App() {
  const [vagas, setVagas] = useState([]);
  const [cursos, setCursos] = useState([]);
  const [conexoes, setConexoes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [erroApi, setErroApi] = useState(false);

  // Dados de segurança (Fallback) caso o seu PostgreSQL esteja vazio
  const vagasDemo = [
    { id: 1, titulo: "Desenvolvedor Java Júnior (Demo)", empresa: "Tech Local", localizacao: "Centro" },
    { id: 2, titulo: "Analista de Recursos Humanos (Demo)", empresa: "Sucesso Empreendimentos", localizacao: "Bairro Industrial" }
  ];
  const cursosDemo = [
    { id: 1, titulo: "Introdução à Lógica (Demo)", cargaHoraria: 40, instituição: "Hub Capacita" }
  ];
  const conexoesDemo = [
    { id: 1, nome: "Wesley (Demo)", role: "USER" }
  ];

  useEffect(() => {
    async function fetchDados() {
      try {
        setLoading(true);
        let falhaVagas = false;

        // 1. Puxa Vagas (Rota Pública)
        try {
          const resVagas = await api.get('/vagas');
          setVagas(resVagas.data || []);
        } catch (error) {
          console.error("Erro ao carregar /vagas:", error.message);
          falhaVagas = true; 
        }

        // 2. Puxa Cursos
        try {
          const resCursos = await api.get('/cursos');
          setCursos(resCursos.data || []);
        } catch (error) {
          console.warn("Rota /cursos indisponível ou falta Token JWT.");
        }

        // 3. Puxa Usuários (Rota Privada)
        try {
          const resConexoes = await api.get('/usuarios');
          setConexoes(resConexoes.data || []);
        } catch (error) {
          console.warn("Rota /usuarios indisponível ou falta Token JWT.");
        }

        setErroApi(falhaVagas);

      } catch (generalError) {
        console.error("Erro geral no carregamento:", generalError);
      } finally {
        setLoading(false);
      }
    }

    fetchDados();
  }, []);

  // Se a API falhar ou estiver sem registros no banco, assume os dados Demo para não quebrar
  const listaVagas = erroApi || vagas.length === 0 ? vagasDemo : vagas;
  const listaCursos = cursos.length === 0 ? cursosDemo : cursos;
  const listaConexoes = conexoes.length === 0 ? conexoesDemo : conexoes;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
      
      {/* NAVBAR */}
      <nav className="bg-white sticky top-0 z-50 border-b border-slate-100 px-6 py-4 flex justify-between items-center shadow-sm">
        <span className="text-2xl font-black text-[#0f2a63]">Emprega<span className="text-[#02c39a]">+</span></span>
        <div className="flex gap-6 text-sm font-semibold text-slate-600">
          <a href="#vagas" className="hover:text-[#02c39a] transition-colors">Vagas</a>
          <a href="#capacitacao" className="hover:text-[#02c39a] transition-colors">Capacitação</a>
        </div>
      </nav>

      {/* BANNER */}
      {erroApi && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-800 text-center py-2 text-xs font-medium">
          ⚠️ Nota: Backend Java não detectado em localhost:8080. Exibindo dados demonstrativos locais.
        </div>
      )}

      {/* DASHBOARD PRINCIPAL */}
      <main className="max-w-6xl mx-auto px-4 py-10 grid md:grid-cols-3 gap-8">
        
        {/* CARD VAGAS */}
        <section className="bg-white rounded-2xl shadow-md p-6 border border-slate-100">
          <h2 className="text-xl font-extrabold text-[#0f2a63] mb-4 flex items-center gap-2">
            <Briefcase className="text-[#02c39a]" size={20} /> Vagas Disponíveis
          </h2>
          <div className="space-y-3">
            {listaVagas.map(vaga => (
              <div key={vaga.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <h4 className="text-sm font-bold text-slate-800">{vaga.titulo}</h4>
                <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                  <Building size={12} /> {vaga.empresa} • <MapPin size={12} /> {vaga.localizacao}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* CARD CURSOS */}
        <section className="bg-white rounded-2xl shadow-md p-6 border border-slate-100">
          <h2 className="text-xl font-extrabold text-[#0f2a63] mb-4 flex items-center gap-2">
            <BookOpen className="text-[#02c39a]" size={20} /> Capacitação
          </h2>
          <div className="space-y-3">
            {listaCursos.map(curso => (
              <div key={curso.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <h4 className="text-sm font-bold text-slate-800">{curso.titulo}</h4>
                <p className="text-xs text-slate-500 mt-1">
                  {curso.institução || "Instituição"} ({curso.cargaHoraria}h)
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* CARD CONEXÕES */}
        <section className="bg-white rounded-2xl shadow-md p-6 border border-slate-100">
          <h2 className="text-xl font-extrabold text-[#0f2a63] mb-4 flex items-center gap-2">
            <Users className="text-[#02c39a]" size={20} /> Ecossistema
          </h2>
          <div className="space-y-3">
            {listaConexoes.map(cx => (
              <div key={cx.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#0f2a63]/10 text-[#0f2a63] font-bold text-xs flex items-center justify-center">
                  {cx.nome ? cx.nome.charAt(0) : "U"}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-800">{cx.nome || "Usuário"}</h4>
                  <p className="text-xs text-slate-400">Perfil: {cx.role || "USER"}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

      </main>
    </div>
  );
}
