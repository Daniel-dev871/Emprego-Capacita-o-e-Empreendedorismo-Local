import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8080', // Porta da sua API Java
});

// Interceptor para injetar o token JWT automaticamente
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token'); 
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default api; // Aqui sim o export default api fica correto!